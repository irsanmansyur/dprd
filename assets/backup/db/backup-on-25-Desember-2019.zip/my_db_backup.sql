#
# TABLE STRUCTURE FOR: keys
#

DROP TABLE IF EXISTS `keys`;

CREATE TABLE `keys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(9) NOT NULL,
  `key` varchar(40) NOT NULL,
  `level` int(2) NOT NULL,
  `ignore_limits` tinyint(1) NOT NULL DEFAULT 0,
  `is_private_key` tinyint(1) NOT NULL DEFAULT 0,
  `ip_addresses` text DEFAULT NULL,
  `date_created` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `keys_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tbl_user` (`id_user`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `keys` (`id`, `user_id`, `key`, `level`, `ignore_limits`, `is_private_key`, `ip_addresses`, `date_created`) VALUES (1, 'user_001', 'wpu123', 1, 0, 0, NULL, 2);


#
# TABLE STRUCTURE FOR: limits
#

DROP TABLE IF EXISTS `limits`;

CREATE TABLE `limits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uri` varchar(255) NOT NULL,
  `count` int(10) NOT NULL,
  `hour_started` int(11) NOT NULL,
  `api_key` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `limits` (`id`, `uri`, `count`, `hour_started`, `api_key`) VALUES (1, 'uri:komentar/index:get', 3, 1577028995, 'wpu123');
INSERT INTO `limits` (`id`, `uri`, `count`, `hour_started`, `api_key`) VALUES (2, 'uri:komentar/index:post', 5, 1577030106, 'wpu123');


#
# TABLE STRUCTURE FOR: tbl_icons
#

DROP TABLE IF EXISTS `tbl_icons`;

CREATE TABLE `tbl_icons` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `name` varchar(35) NOT NULL,
  `code` varchar(128) NOT NULL,
  `kategori` varchar(128) NOT NULL,
  `date_creaated` int(11) NOT NULL DEFAULT current_timestamp(),
  `date_updated` int(11) NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_icons` (`id`, `name`, `code`, `kategori`, `date_creaated`, `date_updated`) VALUES (1, 'Account Balance', '<i class=\"material-icons\"> account_balance </i>', 'Material', 2147483647, 2147483647);
INSERT INTO `tbl_icons` (`id`, `name`, `code`, `kategori`, `date_creaated`, `date_updated`) VALUES (2, 'Account Box', '<i class=\"material-icons\"> account_box </i>', 'Material', 2147483647, 2147483647);
INSERT INTO `tbl_icons` (`id`, `name`, `code`, `kategori`, `date_creaated`, `date_updated`) VALUES (3, 'account Circle', '<i class=\"material-icons\"> account_circle </i>', 'Material', 2147483647, 2147483647);
INSERT INTO `tbl_icons` (`id`, `name`, `code`, `kategori`, `date_creaated`, `date_updated`) VALUES (4, 'troli / belanja', '<i class=\"material-icons\"> add_shopping_cart </i>', '', 2147483647, 2147483647);
INSERT INTO `tbl_icons` (`id`, `name`, `code`, `kategori`, `date_creaated`, `date_updated`) VALUES (5, 'fullscreen', '<i class=\"material-icons\"> all_out </i>', 'Material', 2147483647, 2147483647);
INSERT INTO `tbl_icons` (`id`, `name`, `code`, `kategori`, `date_creaated`, `date_updated`) VALUES (6, 'catatan', '<i class=\"material-icons\"> assignment </i>', 'Material', 2147483647, 2147483647);
INSERT INTO `tbl_icons` (`id`, `name`, `code`, `kategori`, `date_creaated`, `date_updated`) VALUES (7, 'refresh', '<i class=\"material-icons\"> autorenew </i>', 'Material', 2147483647, 2147483647);
INSERT INTO `tbl_icons` (`id`, `name`, `code`, `kategori`, `date_creaated`, `date_updated`) VALUES (8, 'backup', '<i class=\"material-icons\"> backup </i>', 'Material', 2147483647, 2147483647);
INSERT INTO `tbl_icons` (`id`, `name`, `code`, `kategori`, `date_creaated`, `date_updated`) VALUES (9, 'Build', '<i class=\"material-icons\"> build </i>', 'Material', 2147483647, 2147483647);
INSERT INTO `tbl_icons` (`id`, `name`, `code`, `kategori`, `date_creaated`, `date_updated`) VALUES (10, 'check circle', '<i class=\"material-icons\"> check_circle </i>', 'Material', 2147483647, 2147483647);
INSERT INTO `tbl_icons` (`id`, `name`, `code`, `kategori`, `date_creaated`, `date_updated`) VALUES (11, 'done ', '<i class=\"material-icons\"> done_all </i>', 'Material', 2147483647, 2147483647);
INSERT INTO `tbl_icons` (`id`, `name`, `code`, `kategori`, `date_creaated`, `date_updated`) VALUES (12, 'Dashboard', '<i class=\"material-icons\"> dashboard </i>', 'Material', 2147483647, 2147483647);
INSERT INTO `tbl_icons` (`id`, `name`, `code`, `kategori`, `date_creaated`, `date_updated`) VALUES (13, 'delete', '<i class=\"material-icons\"> delete </i>', 'Material', 2147483647, 2147483647);
INSERT INTO `tbl_icons` (`id`, `name`, `code`, `kategori`, `date_creaated`, `date_updated`) VALUES (14, 'lock ', '<i class=\"material-icons\"> fingerprint </i> ', 'Material', 2147483647, 2147483647);
INSERT INTO `tbl_icons` (`id`, `name`, `code`, `kategori`, `date_creaated`, `date_updated`) VALUES (15, 'Home ', '<i class=\"material-icons\"> home </i>', 'Material', 2147483647, 2147483647);
INSERT INTO `tbl_icons` (`id`, `name`, `code`, `kategori`, `date_creaated`, `date_updated`) VALUES (17, 'locked', '<i class=\"material-icons\"> lock </i>', 'Material', 2147483647, 2147483647);
INSERT INTO `tbl_icons` (`id`, `name`, `code`, `kategori`, `date_creaated`, `date_updated`) VALUES (18, 'locked open', '<i class=\"material-icons\"> lock_open </i>', 'Material', 2147483647, 2147483647);
INSERT INTO `tbl_icons` (`id`, `name`, `code`, `kategori`, `date_creaated`, `date_updated`) VALUES (19, 'logout', '<i class=\"material-icons\"> power_settings_new </i>', 'Material', 2147483647, 2147483647);
INSERT INTO `tbl_icons` (`id`, `name`, `code`, `kategori`, `date_creaated`, `date_updated`) VALUES (20, 'folder', '<i class=\"fas fa-fw fa-folder\"></i>', 'Material', 2147483647, 2147483647);
INSERT INTO `tbl_icons` (`id`, `name`, `code`, `kategori`, `date_creaated`, `date_updated`) VALUES (21, 'folder open', '<i class=\"material-icons\"> folder_open </i>', 'Material', 2147483647, 2147483647);
INSERT INTO `tbl_icons` (`id`, `name`, `code`, `kategori`, `date_creaated`, `date_updated`) VALUES (22, 'Icon Font', '<i class=\"material-icons\"> insert_emoticon </i>', 'Material', 2147483647, 2147483647);
INSERT INTO `tbl_icons` (`id`, `name`, `code`, `kategori`, `date_creaated`, `date_updated`) VALUES (24, 'new Folder', '<i class=\"material-icons\"> create_new_folder </i>', 'Material', 2147483647, 2147483647);


#
# TABLE STRUCTURE FOR: tbl_setting
#

DROP TABLE IF EXISTS `tbl_setting`;

CREATE TABLE `tbl_setting` (
  `id_setting` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(49) NOT NULL,
  `title` varchar(180) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_setting`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_setting` (`id_setting`, `name`, `title`, `status`) VALUES (4, 'data_color', 'purple', '1');
INSERT INTO `tbl_setting` (`id_setting`, `name`, `title`, `status`) VALUES (5, 'background_image', 'http://localhost/irsan/dprd/themes/admin/default/assets/img/sidebar-2.jpg', '1');
INSERT INTO `tbl_setting` (`id_setting`, `name`, `title`, `status`) VALUES (6, 'theme_public', 'default', '1');
INSERT INTO `tbl_setting` (`id_setting`, `name`, `title`, `status`) VALUES (7, 'site_title', 'Memangement menu dan user serta pengaturan web', '1');
INSERT INTO `tbl_setting` (`id_setting`, `name`, `title`, `status`) VALUES (11, 'theme_admin', 'default', '1');
INSERT INTO `tbl_setting` (`id_setting`, `name`, `title`, `status`) VALUES (12, 'site_name', 'WEB Managemen', '1');
INSERT INTO `tbl_setting` (`id_setting`, `name`, `title`, `status`) VALUES (13, 'background_color', 'black', '1');


#
# TABLE STRUCTURE FOR: tbl_user
#

DROP TABLE IF EXISTS `tbl_user`;

CREATE TABLE `tbl_user` (
  `id_user` varchar(9) NOT NULL,
  `komisi_id` varchar(9) NOT NULL,
  `name` varchar(25) DEFAULT NULL,
  `email` varchar(128) NOT NULL,
  `password` varchar(256) NOT NULL,
  `tentang_saya` varchar(1000) NOT NULL,
  `no_hp` varchar(15) NOT NULL,
  `alamat` varchar(288) NOT NULL,
  `tgl_lahir` int(12) NOT NULL DEFAULT current_timestamp(),
  `role_id` int(3) NOT NULL,
  `is_active` int(1) NOT NULL,
  `menu_active` enum('yes','no') NOT NULL DEFAULT 'no',
  `date_created` int(11) NOT NULL,
  `date_updated` int(11) NOT NULL DEFAULT current_timestamp(),
  `file_id` varchar(9) CHARACTER SET utf8mb4 NOT NULL,
  PRIMARY KEY (`id_user`),
  UNIQUE KEY `email` (`email`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `tbl_user_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `tbl_user_role` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tbl_user` (`id_user`, `komisi_id`, `name`, `email`, `password`, `tentang_saya`, `no_hp`, `alamat`, `tgl_lahir`, `role_id`, `is_active`, `menu_active`, `date_created`, `date_updated`, `file_id`) VALUES ('user_001', '', 'Irsan_mansyur', 'portofolio@gmail.com', '$2y$10$atyi8D112NQRFL.qwXShm.7KZfuRjj95moeIAE0gSj/fcFaEMJmaO', 'g', '085298884534', 'Ds. Jongbiru 001/001 kec. Gampengrejo - Kediri', 0, 1, 1, 'yes', 1567261992, 2147483647, 'f001');
INSERT INTO `tbl_user` (`id_user`, `komisi_id`, `name`, `email`, `password`, `tentang_saya`, `no_hp`, `alamat`, `tgl_lahir`, `role_id`, `is_active`, `menu_active`, `date_created`, `date_updated`, `file_id`) VALUES ('user_003', 'kms_001', 'irsan mansyur', 'firsanfile@gmail.com', '$2y$10$gwK9qh2N0V/xCWCWlcRQFucYFBehSHwqQ.iTharE1wmN4niXP63ny', 'Ini Tentang Saya\r\n', '085298884534', 'Ds. Jongbiru 001/001 kec. Gampengrejo - Kediri', 0, 2, 1, 'no', 1576712780, 2147483647, 'file_002');
INSERT INTO `tbl_user` (`id_user`, `komisi_id`, `name`, `email`, `password`, `tentang_saya`, `no_hp`, `alamat`, `tgl_lahir`, `role_id`, `is_active`, `menu_active`, `date_created`, `date_updated`, `file_id`) VALUES ('user_005', 'kms_003', 'irsanm', 'dirsan00mansyur@gmail.com', '$2y$10$NIQ.mURLRHLaKKyGaG4p4ONlyDoKd4fIOU4jeR.eiXzHnd08bqqbC', '', '085298884534', 'Ds. Jongbiru 001/001 kec. Gampengrejo - Kediri', 0, 2, 1, 'no', 0, 1576919327, 'file_003');
INSERT INTO `tbl_user` (`id_user`, `komisi_id`, `name`, `email`, `password`, `tentang_saya`, `no_hp`, `alamat`, `tgl_lahir`, `role_id`, `is_active`, `menu_active`, `date_created`, `date_updated`, `file_id`) VALUES ('user_006', '', 'masyarakat', 'masyarakat@gmail.com', '$2y$10$1AEJrpEAFDukEqEVH6hbSeNtA/ncZyuQcLvLMynq1HLP7ccxYL6gW', '', '085298884534', 'Ds. Jongbiru 001/001 kec. Gampengrejo - Kediri', 0, 3, 1, 'no', 0, 1577263462, 'file_008');
INSERT INTO `tbl_user` (`id_user`, `komisi_id`, `name`, `email`, `password`, `tentang_saya`, `no_hp`, `alamat`, `tgl_lahir`, `role_id`, `is_active`, `menu_active`, `date_created`, `date_updated`, `file_id`) VALUES ('user_007', '', 'masyarakat1', 'masyarakat1@gmail.com', '$2y$10$0wKcZvzYGxDDTT2lLGTZcuEAFzsNhUXqruqOXLdgfadep5gHtG.ca', '', '085298884534', 'Ds. Jongbiru 001/001 kec. Gampengrejo - Kediri', 0, 3, 1, 'no', 0, 1577263628, 'file_008');
INSERT INTO `tbl_user` (`id_user`, `komisi_id`, `name`, `email`, `password`, `tentang_saya`, `no_hp`, `alamat`, `tgl_lahir`, `role_id`, `is_active`, `menu_active`, `date_created`, `date_updated`, `file_id`) VALUES ('user_008', '', 'masyarakat2bb', 'masyarakat2@gmail.com', '$2y$10$E1DVG4axLrP/wmw6t0zY5ecHtn5dqLkuNXqKx2Z0i3/XemzDMPrba', 'ihj', '085298884534', 'Ds. Jongbiru 001/001 kec. Gampengrejo - Kediri', 493200, 3, 1, 'no', 0, 1577265218, 'file_009');
INSERT INTO `tbl_user` (`id_user`, `komisi_id`, `name`, `email`, `password`, `tentang_saya`, `no_hp`, `alamat`, `tgl_lahir`, `role_id`, `is_active`, `menu_active`, `date_created`, `date_updated`, `file_id`) VALUES ('user_009', '', 'sddfgffg', 'portofolio@gmail.comf', '$2y$10$KJ/ZaWf09AElsFDrJVJlAO8K10pkZFC.Y6FSJym5nIt6o0kGZ0.Yi', '', '085298884534', 'fffdfdf', 12, 3, 0, '', 1577282913, 1577282913, 'file_001');
INSERT INTO `tbl_user` (`id_user`, `komisi_id`, `name`, `email`, `password`, `tentang_saya`, `no_hp`, `alamat`, `tgl_lahir`, `role_id`, `is_active`, `menu_active`, `date_created`, `date_updated`, `file_id`) VALUES ('user_010', '', 'masyarakat66', 'portofoddlio@gmail.com', '$2y$10$3RLZvfDcFArXEGXxxUIWp.hQvR9TQWcTi6m9p0Nu6OrxZ1JDISejC', '', '085298884534', 'Ds. Jongbiru 001/001 kec. Gampengrejo - Kediri', 662058000, 3, 0, '', 1577283146, 1577283146, 'file_001');
INSERT INTO `tbl_user` (`id_user`, `komisi_id`, `name`, `email`, `password`, `tentang_saya`, `no_hp`, `alamat`, `tgl_lahir`, `role_id`, `is_active`, `menu_active`, `date_created`, `date_updated`, `file_id`) VALUES ('user_011', '', 'irsan mansyur', 'irsan00masnyur@gmail.com', '$2y$10$EhyNg1i6wUCM19dCN/.UHu2kYeQveaLc4pvCwx/AbSqp4vCOYVhaC', '', '085298884534', 'Ds. Jongbiru 001/001 kec. Gampengrejo - Kediri', 835462800, 3, 0, '', 1577283681, 1577283681, 'file_001');
INSERT INTO `tbl_user` (`id_user`, `komisi_id`, `name`, `email`, `password`, `tentang_saya`, `no_hp`, `alamat`, `tgl_lahir`, `role_id`, `is_active`, `menu_active`, `date_created`, `date_updated`, `file_id`) VALUES ('user_012', '', 'irsan mansyur', 'irsan00mansyur@gmail.com', '$2y$10$DqskIPlmALr/rPz1Fo7ha.j780Vw898xTFAoA9UvbV0BHCFV/YqJm', '', '085298884534', 'Ds. Jongbiru 001/001 kec. Gampengrejo - Kediri', 835462800, 3, 1, '', 1577283709, 1577283709, 'file_001');
INSERT INTO `tbl_user` (`id_user`, `komisi_id`, `name`, `email`, `password`, `tentang_saya`, `no_hp`, `alamat`, `tgl_lahir`, `role_id`, `is_active`, `menu_active`, `date_created`, `date_updated`, `file_id`) VALUES ('user_013', '', 'irsanm f', 'portddsfolio@gmail.com', '$2y$10$n8WiRysMRmNjRtARky7pp.G56Dku8O.2LPpqfQpRUwnS5qFXaJYkm', '', '085298884534', 'Ds. Jongbiru 001/001 kec. Gampengrejo - Kediri', 662058000, 3, 1, '', 1577285656, 1577285656, 'file_011');


#
# TABLE STRUCTURE FOR: tbl_user_about
#

DROP TABLE IF EXISTS `tbl_user_about`;

CREATE TABLE `tbl_user_about` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(46) NOT NULL,
  `file_id` varchar(9) CHARACTER SET utf8mb4 NOT NULL,
  `motivasi` varchar(400) NOT NULL,
  `pekerjaan` varchar(300) NOT NULL,
  `tentang_saya` varchar(1000) NOT NULL,
  `id_gallery` int(5) NOT NULL,
  `user_id` varchar(9) CHARACTER SET utf8 NOT NULL,
  `no_hp` varchar(20) NOT NULL,
  `nip` varchar(10) NOT NULL,
  `situs` varchar(188) NOT NULL,
  `alamat` varchar(288) NOT NULL,
  `tgl_lahir` int(12) NOT NULL,
  `date_updated` int(11) NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `file_id` (`file_id`),
  KEY `user_about_ibfk_1` (`user_id`),
  CONSTRAINT `tbl_user_about_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tbl_user` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_user_about` (`id`, `name`, `file_id`, `motivasi`, `pekerjaan`, `tentang_saya`, `id_gallery`, `user_id`, `no_hp`, `nip`, `situs`, `alamat`, `tgl_lahir`, `date_updated`) VALUES (1, 'Admin WEB', 'file_001', 'Tak Ada usaha yang menghianati hasil. Yakinlah semakin besar usahamu, semakin besar kamu mencapai impianmu.', 'Petani|Guru Honorer|Pegawai', '&quot;Tak Ada usaha yang menghianati hasil. Yakinlah semakin besar usahamu, semakin besar kamu mencapai impianmu&quot;', 1, 'user_001', '085298198343', '161290', 'http://www.irsandp.com', 'Kamp. Sarroanging, Desa Mappilawing, Kec. eremerasa, Kab. Bantaeng', 1795021200, 2147483647);


#
# TABLE STRUCTURE FOR: tbl_user_access_menu
#

DROP TABLE IF EXISTS `tbl_user_access_menu`;

CREATE TABLE `tbl_user_access_menu` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `role_id` int(2) NOT NULL,
  `menu_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `menu_id` (`menu_id`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `tbl_user_access_menu_ibfk_1` FOREIGN KEY (`menu_id`) REFERENCES `tbl_user_menu` (`id_menu`),
  CONSTRAINT `tbl_user_access_menu_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `tbl_user_role` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_user_access_menu` (`id`, `role_id`, `menu_id`) VALUES (60, 1, 1);
INSERT INTO `tbl_user_access_menu` (`id`, `role_id`, `menu_id`) VALUES (61, 1, 2);
INSERT INTO `tbl_user_access_menu` (`id`, `role_id`, `menu_id`) VALUES (62, 2, 2);
INSERT INTO `tbl_user_access_menu` (`id`, `role_id`, `menu_id`) VALUES (70, 1, 9);
INSERT INTO `tbl_user_access_menu` (`id`, `role_id`, `menu_id`) VALUES (77, 2, 28);
INSERT INTO `tbl_user_access_menu` (`id`, `role_id`, `menu_id`) VALUES (79, 3, 2);
INSERT INTO `tbl_user_access_menu` (`id`, `role_id`, `menu_id`) VALUES (82, 1, 28);


#
# TABLE STRUCTURE FOR: tbl_user_file
#

DROP TABLE IF EXISTS `tbl_user_file`;

CREATE TABLE `tbl_user_file` (
  `id_file` varchar(9) NOT NULL,
  `user_id` varchar(9) CHARACTER SET utf8 NOT NULL,
  `file` varchar(128) NOT NULL,
  `type` enum('1','2','3','4') NOT NULL DEFAULT '1' COMMENT '1 .Image, 2.Document, 3.MP3, 4.Video',
  PRIMARY KEY (`id_file`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbl_user_file` (`id_file`, `user_id`, `file`, `type`) VALUES ('f001', 'user_001', '3_X_4_.jpg', '1');
INSERT INTO `tbl_user_file` (`id_file`, `user_id`, `file`, `type`) VALUES ('file_001', '', 'default.png', '1');
INSERT INTO `tbl_user_file` (`id_file`, `user_id`, `file`, `type`) VALUES ('file_002', 'user_003', '3_X_4_1.jpg', '1');
INSERT INTO `tbl_user_file` (`id_file`, `user_id`, `file`, `type`) VALUES ('file_003', 'user_005', '3_X_4_1.jpg', '1');
INSERT INTO `tbl_user_file` (`id_file`, `user_id`, `file`, `type`) VALUES ('file_008', 'user_007', 'default.jpg', '1');
INSERT INTO `tbl_user_file` (`id_file`, `user_id`, `file`, `type`) VALUES ('file_009', 'user_008', '3_x_4_5.jpg', '1');
INSERT INTO `tbl_user_file` (`id_file`, `user_id`, `file`, `type`) VALUES ('file_011', 'user_013', '3_x_4_4.jpg', '');


#
# TABLE STRUCTURE FOR: tbl_user_menu
#

DROP TABLE IF EXISTS `tbl_user_menu`;

CREATE TABLE `tbl_user_menu` (
  `id_menu` int(11) NOT NULL AUTO_INCREMENT,
  `menu` varchar(88) NOT NULL,
  PRIMARY KEY (`id_menu`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_user_menu` (`id_menu`, `menu`) VALUES (1, 'admin');
INSERT INTO `tbl_user_menu` (`id_menu`, `menu`) VALUES (2, 'user');
INSERT INTO `tbl_user_menu` (`id_menu`, `menu`) VALUES (9, 'Menu Managements');
INSERT INTO `tbl_user_menu` (`id_menu`, `menu`) VALUES (28, 'Komisi');


#
# TABLE STRUCTURE FOR: tbl_user_role
#

DROP TABLE IF EXISTS `tbl_user_role`;

CREATE TABLE `tbl_user_role` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_user_role` (`id`, `name`) VALUES (1, 'admin');
INSERT INTO `tbl_user_role` (`id`, `name`) VALUES (2, 'komisi');
INSERT INTO `tbl_user_role` (`id`, `name`) VALUES (3, 'masyarakat');


#
# TABLE STRUCTURE FOR: tbl_user_sub_menu
#

DROP TABLE IF EXISTS `tbl_user_sub_menu`;

CREATE TABLE `tbl_user_sub_menu` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `menu_id` int(11) NOT NULL,
  `title` varchar(128) NOT NULL,
  `url` varchar(128) NOT NULL,
  `icon_id` int(6) NOT NULL DEFAULT 10,
  `is_active` int(1) NOT NULL,
  `class` varchar(120) NOT NULL,
  `method` varchar(122) NOT NULL,
  `akses` int(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `menu_id` (`menu_id`),
  KEY `icon_id` (`icon_id`),
  CONSTRAINT `tbl_user_sub_menu_ibfk_1` FOREIGN KEY (`menu_id`) REFERENCES `tbl_user_menu` (`id_menu`),
  CONSTRAINT `tbl_user_sub_menu_ibfk_2` FOREIGN KEY (`icon_id`) REFERENCES `tbl_icons` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon_id`, `is_active`, `class`, `method`, `akses`) VALUES (45, 1, 'Role Acces', 'admin/admin/role', 3, 1, 'admin', 'role', 0);
INSERT INTO `tbl_user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon_id`, `is_active`, `class`, `method`, `akses`) VALUES (50, 2, 'Profile User', 'admin/user/profile', 15, 1, 'user', 'profile', 0);
INSERT INTO `tbl_user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon_id`, `is_active`, `class`, `method`, `akses`) VALUES (51, 9, 'Menu Akses', 'admin/menu', 20, 1, 'menu', 'index', 0);
INSERT INTO `tbl_user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon_id`, `is_active`, `class`, `method`, `akses`) VALUES (52, 9, 'Sub Menu ', 'admin/menu/submenu', 21, 1, 'menu', 'submenu', 0);
INSERT INTO `tbl_user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon_id`, `is_active`, `class`, `method`, `akses`) VALUES (54, 2, 'Change Password', 'admin/user/changepassword', 13, 1, 'user', 'changepassword', 0);
INSERT INTO `tbl_user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon_id`, `is_active`, `class`, `method`, `akses`) VALUES (56, 2, 'User Blocked', 'admin/user/blocked', 11, 1, 'user', 'blocked', 1);
INSERT INTO `tbl_user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon_id`, `is_active`, `class`, `method`, `akses`) VALUES (58, 1, 'Setting WEB', 'admin/admin/setting', 2, 1, 'admin', 'setting', 0);
INSERT INTO `tbl_user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon_id`, `is_active`, `class`, `method`, `akses`) VALUES (59, 1, 'Backup', 'admin/admin/backup', 8, 1, 'admin', 'backup', 0);
INSERT INTO `tbl_user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon_id`, `is_active`, `class`, `method`, `akses`) VALUES (60, 2, 'Search', 'admin/search', 2, 1, 'search', 'index', 0);
INSERT INTO `tbl_user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon_id`, `is_active`, `class`, `method`, `akses`) VALUES (61, 2, 'Dashboard', 'admin/dashboard', 1, 1, 'dashboard', 'index', 0);
INSERT INTO `tbl_user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon_id`, `is_active`, `class`, `method`, `akses`) VALUES (62, 9, 'Menu Icons', 'admin/icon', 22, 1, 'icon', 'index', 0);
INSERT INTO `tbl_user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon_id`, `is_active`, `class`, `method`, `akses`) VALUES (64, 28, 'Index', 'admin/komisi', 1, 1, 'komisi', 'index', 0);
INSERT INTO `tbl_user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon_id`, `is_active`, `class`, `method`, `akses`) VALUES (65, 28, 'User Komisi', 'admin/komisi/user', 3, 1, 'komisi', 'user', 0);


#
# TABLE STRUCTURE FOR: tbl_user_token
#

DROP TABLE IF EXISTS `tbl_user_token`;

CREATE TABLE `tbl_user_token` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(128) NOT NULL,
  `token` varchar(128) NOT NULL,
  `date_created` int(11) NOT NULL,
  `qty` int(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `email` (`email`),
  CONSTRAINT `tbl_user_token_ibfk_1` FOREIGN KEY (`email`) REFERENCES `tbl_user` (`email`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_user_token` (`id`, `email`, `token`, `date_created`, `qty`) VALUES (40, 'irsan00masnyur@gmail.com', '5e0370618a67a', 1577283686, 0);
INSERT INTO `tbl_user_token` (`id`, `email`, `token`, `date_created`, `qty`) VALUES (48, 'portddsfolio@gmail.com', '5e037818c65ea', 1577285659, 0);


#
# TABLE STRUCTURE FOR: tbl_visitor
#

DROP TABLE IF EXISTS `tbl_visitor`;

CREATE TABLE `tbl_visitor` (
  `id_visitor` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(20) NOT NULL,
  `os` varchar(30) NOT NULL,
  `browser` varchar(130) NOT NULL,
  `date_created` int(11) NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_visitor`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbl_visitor` (`id_visitor`, `ip`, `os`, `browser`, `date_created`) VALUES (24, '::1', 'Windows 7', 'Chrome', 1575354941);
INSERT INTO `tbl_visitor` (`id_visitor`, `ip`, `os`, `browser`, `date_created`) VALUES (25, '::1', 'Windows 7', 'Chrome', 1575485817);
INSERT INTO `tbl_visitor` (`id_visitor`, `ip`, `os`, `browser`, `date_created`) VALUES (26, '::1', 'Windows 7', 'Chrome', 1576226672);
INSERT INTO `tbl_visitor` (`id_visitor`, `ip`, `os`, `browser`, `date_created`) VALUES (27, '::1', 'Windows 10', 'Chrome', 1576646890);
INSERT INTO `tbl_visitor` (`id_visitor`, `ip`, `os`, `browser`, `date_created`) VALUES (28, '::1', 'Windows 10', 'Chrome', 1576769761);
INSERT INTO `tbl_visitor` (`id_visitor`, `ip`, `os`, `browser`, `date_created`) VALUES (29, '::1', 'Windows 10', 'Chrome', 1577003890);
INSERT INTO `tbl_visitor` (`id_visitor`, `ip`, `os`, `browser`, `date_created`) VALUES (30, '::1', 'Unknown Platform', '', 1577090975);
INSERT INTO `tbl_visitor` (`id_visitor`, `ip`, `os`, `browser`, `date_created`) VALUES (31, '::1', 'Windows 10', 'Chrome', 1577185585);
INSERT INTO `tbl_visitor` (`id_visitor`, `ip`, `os`, `browser`, `date_created`) VALUES (32, '::1', 'Windows 10', 'Chrome', 1577302560);


#
# TABLE STRUCTURE FOR: web_aspirasi
#

DROP TABLE IF EXISTS `web_aspirasi`;

CREATE TABLE `web_aspirasi` (
  `id_aspirasi` varchar(9) CHARACTER SET utf8 NOT NULL,
  `message` text NOT NULL,
  `komisi_id` varchar(9) CHARACTER SET utf8 NOT NULL,
  `user_id` varchar(9) CHARACTER SET utf8 NOT NULL,
  `status` enum('1','2','3','4') NOT NULL COMMENT '1 = Ditanggapi, 2 = Dibaca, 3 = belum dibaca, 4 = tidak terkirim kekomisi ',
  PRIMARY KEY (`id_aspirasi`),
  KEY `user_id` (`user_id`),
  KEY `web_aspirasi_ibfk_2` (`komisi_id`),
  CONSTRAINT `web_aspirasi_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tbl_user` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `web_aspirasi_ibfk_2` FOREIGN KEY (`komisi_id`) REFERENCES `web_komisi` (`id_komisi`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `web_aspirasi` (`id_aspirasi`, `message`, `komisi_id`, `user_id`, `status`) VALUES ('asp_001', 'hjkhk\r\nerhuggh', 'kms_001', 'user_003', '3');


#
# TABLE STRUCTURE FOR: web_komentar
#

DROP TABLE IF EXISTS `web_komentar`;

CREATE TABLE `web_komentar` (
  `id_komentar` varchar(9) CHARACTER SET utf8 NOT NULL,
  `komentar` varchar(290) NOT NULL,
  `aspirasi_id` varchar(9) CHARACTER SET utf8 NOT NULL,
  `komisi_id` varchar(9) CHARACTER SET utf8 NOT NULL,
  `user_id` varchar(9) CHARACTER SET utf8 NOT NULL,
  `type` int(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id_komentar`),
  KEY `aspirasi_id` (`aspirasi_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `web_komentar_ibfk_1` FOREIGN KEY (`aspirasi_id`) REFERENCES `web_aspirasi` (`id_aspirasi`) ON DELETE CASCADE,
  CONSTRAINT `web_komentar_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `tbl_user` (`id_user`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `web_komentar` (`id_komentar`, `komentar`, `aspirasi_id`, `komisi_id`, `user_id`, `type`) VALUES ('kmtr_001', 'ifffssffff', 'asp_001', '', 'user_001', 3);
INSERT INTO `web_komentar` (`id_komentar`, `komentar`, `aspirasi_id`, `komisi_id`, `user_id`, `type`) VALUES ('kmtr_002', 'Komentar kedua', 'asp_001', '', 'user_001', 3);
INSERT INTO `web_komentar` (`id_komentar`, `komentar`, `aspirasi_id`, `komisi_id`, `user_id`, `type`) VALUES ('kmtr_003', 'Komentar kedua', 'asp_001', '', 'user_001', 3);
INSERT INTO `web_komentar` (`id_komentar`, `komentar`, `aspirasi_id`, `komisi_id`, `user_id`, `type`) VALUES ('kmtr_004', 'Komentar kedua', 'asp_001', '', 'user_003', 3);


#
# TABLE STRUCTURE FOR: web_komisi
#

DROP TABLE IF EXISTS `web_komisi`;

CREATE TABLE `web_komisi` (
  `id_komisi` varchar(9) CHARACTER SET utf8 NOT NULL,
  `name` varchar(129) NOT NULL,
  PRIMARY KEY (`id_komisi`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `web_komisi` (`id_komisi`, `name`) VALUES ('kms_001', 'komisi A');
INSERT INTO `web_komisi` (`id_komisi`, `name`) VALUES ('kms_002', 'Komisi B');
INSERT INTO `web_komisi` (`id_komisi`, `name`) VALUES ('kms_003', 'Komisi C');


#
# TABLE STRUCTURE FOR: web_komisi_label
#

DROP TABLE IF EXISTS `web_komisi_label`;

CREATE TABLE `web_komisi_label` (
  `id_label` varchar(9) CHARACTER SET utf8 NOT NULL,
  `label` varchar(129) NOT NULL,
  `komisi_id` varchar(9) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id_label`),
  KEY `komisi_id` (`komisi_id`),
  CONSTRAINT `web_komisi_label_ibfk_1` FOREIGN KEY (`komisi_id`) REFERENCES `web_komisi` (`id_komisi`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `web_komisi_label` (`id_label`, `label`, `komisi_id`) VALUES ('lbl_002', 'dffffdf', 'kms_003');
INSERT INTO `web_komisi_label` (`id_label`, `label`, `komisi_id`) VALUES ('lbl_003', 'Ini salah nya', 'kms_001');


#
# TABLE STRUCTURE FOR: web_komisi_user
#

DROP TABLE IF EXISTS `web_komisi_user`;

CREATE TABLE `web_komisi_user` (
  `id_k_u` varchar(9) CHARACTER SET utf8 NOT NULL,
  `komisi_id` varchar(9) CHARACTER SET utf8 NOT NULL,
  `user_id` varchar(9) CHARACTER SET utf8 NOT NULL,
  `status` int(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id_k_u`),
  KEY `user_id` (`user_id`),
  KEY `komisi_id` (`komisi_id`),
  CONSTRAINT `web_komisi_user_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tbl_user` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `web_komisi_user_ibfk_2` FOREIGN KEY (`komisi_id`) REFERENCES `web_komisi` (`id_komisi`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `web_komisi_user` (`id_k_u`, `komisi_id`, `user_id`, `status`) VALUES ('k_us_001', 'kms_001', 'user_003', 0);
INSERT INTO `web_komisi_user` (`id_k_u`, `komisi_id`, `user_id`, `status`) VALUES ('k_u_a_002', 'kms_001', 'user_005', 1);


